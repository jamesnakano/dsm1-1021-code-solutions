print("""
  ===============
  ds-prep-example
  ===============
""")

print("I would like to analyze {} to learn/predict {}.\n".format(

  # write what you would like to analyze in the quotes here 👇

  "____",

  # write what you would like to learn from that analysis here 👇

  "____"

))
